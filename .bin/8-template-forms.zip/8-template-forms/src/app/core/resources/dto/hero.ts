export interface Hero {
  readonly id: number;
  name: string;
  power?: string;
  alterEgo?: string;
}