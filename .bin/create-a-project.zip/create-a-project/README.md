# AngularTourOfHeroes

This folder contains the local installation of the [Angular CLI](https://github.com/angular/angular-cli) version 20.1.0.

## Project scaffolding

Use the `ng new` command to start creating your *Tour of Heroes* application.
