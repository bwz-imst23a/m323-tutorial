export interface Hero {
  readonly id: number;
  name: string;
}